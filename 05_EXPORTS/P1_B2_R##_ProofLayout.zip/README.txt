Placeholder artifact. Regenerate as needed.
